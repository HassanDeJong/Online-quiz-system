import java.util.Scanner; 
public class Score extends Quiz{
    private double totalScore;
    int marks;
    

    public Score(String quizName,String quizType, String quizDescr, double totalScore)
    {
        super(quizName, quizType, quizDescr);
        this.totalScore = totalScore;
    }
    public double addScore()
    {
        this.totalScore = marks+2;
        return totalScore;
    }
}
