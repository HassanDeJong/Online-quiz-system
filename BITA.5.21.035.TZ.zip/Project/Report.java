public class Report extends Quiz {
private String Student;
private String Course;
int totalScore;
    
    

    public Report(String quizName,String quizType, String quizDescr)
    {
        super(quizName, quizType, quizDescr);
        Student = Student;
        Course = Course;
    
    }
    public void rateScore(String Student,String Course)
    {
        if (totalScore > 5) 
        {
        System.out.println("The student "+Student+" who is taking "+Course+ " did well on his/ her quiz: \nWell done: ");    
        } 
        else
        {
        System.out.println("The student "+Student+" who is taking "+Course+ " did not have great perfomanceon his/her quiz: ");
        System.out.println("");
        System.out.println("Try your best next time: ");
        }    
    }}

    

