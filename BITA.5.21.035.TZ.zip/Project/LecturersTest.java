public class LecturersTest {
 
        public static void main(String[] args) {
            
        Lecturers obj1 = new Lecturers("Hassan","shauri2345@gmail.com","BITA/5/21/0/35/TZ");
        obj1.addQuiz();
        obj1.addAnswers();
        obj1.getReport();
        }
    }
    

