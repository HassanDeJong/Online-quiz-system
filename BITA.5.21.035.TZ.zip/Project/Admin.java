import java.util.Scanner;
public class Admin {
private String name;
private String username;
private String password;
private String email;
private String ID;
private String students;
private String lecturers;

String username_ans, password1;

public Admin(String name , String email, String ID)
{
    this.name = name;
    this.email = email;
    this.ID = ID;
   
}
public void login(){
    Scanner input = new Scanner(System.in);
    System.out.println(" create your username: ");
    this.username = input.next();
    System.out.println(" create your password: ");
    password = input.next();
    System.out.println("Confirm your password");
    String password_conf = input.next();
    if (password == password_conf)
    {
        password_conf = password;  
         
    } 
    else
    {
     System.out.println("Password does not match");   
     
    }
   

    System.out.println("You have successfully created your account. \nPlease use the same info when you log in the system: ");
    System.out.println();
    System.out.println();

    System.out.println("Press 1 if you want to log in or press any other key to exit: ");
    String answer = input.next();
    if (answer == "1") 
    {
        System.out.println("Welcome to login page: ");
    } 
    else 
    {
    System.out.println("Thank you and goodbye: ");
    
    }
    
    System.out.println();
    System.out.println();

    do
    {
    System.out.println("Enter your username: ");
    String username_ans = input.next();
    System.out.println("Enter your password: ");
    String password1 = input.next();
    if (password1 == password && username_ans == username)
    {
        password1 = password;
        username_ans = username;
        System.out.println("Hello Admin! You have been logged in succefully: ");    
    } 
    else
    {
        System.out.println("Invalid username or  password: ");
    
        
    } 
    } while( username_ans != username || password1 != password);
}
public void manageStudents( String Students)
{
System.out.println("Hello "+Students+"Welcome to the quiz: ");
}
public void manageLecturers( String Lecturers)
{
    System.out.println("Hello "+Lecturers+"Welcome to the quiz: ");
}
public void setName( String n)
{
name = n;
}
public void setEmail( String e)
{
email = e;
}
public void setID( String i)
{
ID = i;
}

public String getName()
{
    return name;
}
public String getEmail()
{
    return email;
}
public String getID()
{
    return ID;
}

public String getReport( )
{
return "My name is "+getName()+" And my email is "+getEmail()+". With working ID  "+getID();
}
}
