public class TestQuiz {
    public static void main(String args []) {
        
        Quiz obj1 = new Quiz("Math", "MCQ questions", "Attempt all questions provided: ");
        obj1.takeQuiz();
        obj1.endQuiz();
        }
    }
    


