public class Lecturers extends Admin{
    private String staffID;

    public Lecturers(String name,String email,String ID)
    {
        super(name, email,ID);
        ID = staffID;
    }
    public void addQuiz(){
       

      
System.out.println("\n 1.School of business is found at:");
System.out.println("a) Maruhubi ");
System.out.println("b) Tunguu");
System.out.println("c) Chwaka \n");

System.out.println("\n 2.School of tourism is found at:");
System.out.println("a) Maruhubi ");
System.out.println("b) Tunguu");
System.out.println("c) Chwaka \n");

System.out.println("\n 3.School of health is found at:");
System.out.println("a) mbweni ");
System.out.println("b) Tunguu");
System.out.println("c) Chwaka \n");

System.out.println("\n 4.Main Campus is found at:");
System.out.println("a) Maruhubi ");
System.out.println("b) Tunguu");
System.out.println("c) Chwaka \n");

System.out.println("\n 5.Who is teaching programming between the following?");
System.out.println("a) Mr.Mmanga ");
System.out.println("b) Dr. Rams");
System.out.println("c) Mr Mjaka \n");

}
public void addAnswers()
{
    System.out.println("1 = c");
    System.out.println("2 = b");
    System.out.println("3 = q");
    System.out.println("4= b");
    System.out.println("5 = q");
}
@Override
public String getReport()
{
    return "The quiz for the day has been completed thank you for your good work";
}

}