

public class AdminTest {
public static void main(String[] args) {
        
Admin obj1 = new Admin("Hassan","example@gmail.com","XX123");
obj1.login();
}
}
