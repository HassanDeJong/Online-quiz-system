import java.util.Scanner;
public class Student extends Admin{
private String registrationNumber;

 public Student(String name , String email, String ID)
{
    super(name,email,ID);
    ID = registrationNumber;
}
public void attemptQuiz()
{

    Scanner input = new Scanner(System.in);
    System.out.println("Press any button to start quiz ");
    String ans = input.next();
     {
    System.out.println("Good luck on your quiz: ");
    }
     System.out.println("Lets start now");
     
    }
    public String startQuiz()
    {
        int marks =0; 
        String answer;
        
Scanner input = new Scanner(System.in);
System.out.println();
System.out.println("\n If you get the correct answer you'll earn 2 marks.\n\n\n\n");
System.out.println("\n 1.School of business is found at:");
System.out.println("a) Maruhubi ");
System.out.println("b) Tunguu");
System.out.println("c) Chwaka \n");
System.out.println("Pick your answer: ");
answer = input.next();

if (answer == "c" || answer == "C"){
    System.out.println("Correct! ");
    marks +=2;
}
else
{
    System.out.println("Not Correct");
}

System.out.println("\n 2.School of tourism is found at:");
System.out.println("a) Maruhubi ");
System.out.println("b) Tunguu");
System.out.println("c) Chwaka \n");


if (answer == "a" || answer == "A"){
    System.out.println("Correct! ");
    marks +=2;
}
else
{
    System.out.println("Not Correct");
}


System.out.println("\n 3.School of health is found at:");
System.out.println("a) mbweni ");
System.out.println("b) Tunguu");
System.out.println("c) Chwaka \n");
System.out.println("Pick your answer: ");
answer = input.next();

if (answer == "c" || answer == "C"){
    System.out.println("Correct! ");
    marks +=2;
}
else
{
    System.out.println("Not Correct");
}
System.out.println("\n 4.Main Campus is found at:");
System.out.println("a) Maruhubi ");
System.out.println("b) Tunguu");
System.out.println("c) Chwaka \n");
System.out.println("Pick your answer: ");
answer = input.next();

if (answer == "c" || answer == "C"){
    System.out.println("Correct! ");
    marks +=2;
}
else
{
    System.out.println("Not Correct");
}
System.out.println("\n 5.Who is teaching programming between the following?");
System.out.println("a) Mr.Mmanga ");
System.out.println("b) Dr. Rams");
System.out.println("c) Mr Mjaka \n");
System.out.println("Pick your answer: ");
answer = input.next();

if (answer == "c" || answer == "C"){
    System.out.println("Correct! ");
    marks +=2;
}
else
{
    System.out.println("Not Correct");
}
System.out.println("\nThat is the end of the quiz.");
System.out.println("\n \n Your score is"+marks+"Out of 10.");
if (marks >=6){
    System.out.println("Well done! You did a great job...");
}
else
{
   System.out.println("Your score is low try again next time...");

}

return " Thank you";

}
public void submitQuiz()
{
    System.out.println("Please press 1 to submit quiz or 2 to goa nd take another quiz ");
}
@Override
public String getReport()
{
    return " Thank you for partici[ating in this quiz: ";
}

   
    }
