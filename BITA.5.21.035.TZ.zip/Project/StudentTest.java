public class StudentTest {
    public static void main(String[] args) {
        
    Student obj1 = new Student("Hassan","shauri2345@gmail.com","BITA/5/21/0/35/TZ");
    System.out.println();
    obj1.attemptQuiz();
    obj1.startQuiz();
    obj1.getReport();
    }
}
