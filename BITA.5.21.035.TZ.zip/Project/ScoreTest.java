public class ScoreTest {
    public static void main(String args[]) 
    {
    
    Score obj1 = new Score("Math", "MCQ questions", "Attempt all questions provided: ");
    obj1.addScore();    
    }
}
