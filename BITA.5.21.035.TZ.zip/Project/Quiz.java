import java.util.Scanner;
public class Quiz {
    

private String quizName;
private String quizType;
private String quizDescr;

public Quiz(String quizName,String quizType, String quizDescr)
{
this.quizName = quizName;
this.quizType = quizType;
this.quizDescr = quizDescr;
}
public void takeQuiz()
{
    Scanner input = new Scanner(System.in);
    System.out.println("Please enter your name and your registration number");
    String info = input.next();
    System.out.println("The quiz has been uploaded by the lecturer so please get ready to attempt it: ");
    System.out.println();
    System.out.println();
    System.out.println("Please pick the course and the lectrurer you want to attempt : ");
    System.out.println("");
    System.out.println("");
    System.out.println("When you are done please submit the quiz for grading ");
}
public void endQuiz()
{
    System.out.println("When you are done please submit the quiz for grading ");
    System.out.println("That will be the end for your quiz\nThank you..... ");
}
}




