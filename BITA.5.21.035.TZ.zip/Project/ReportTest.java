public class ReportTest {
    public static void main(String args [])
    {
    Report obj1 = new Report("Math","MCQ questions","Answer all questions");
    obj1.rateScore("Hassan","BITA YEAR 1");

    }
}
